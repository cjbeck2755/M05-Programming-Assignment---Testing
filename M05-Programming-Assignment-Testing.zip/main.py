assert sum([1, 2, 3]) == 6, "Should be 6"
#assert sum([1, 7, 3]) == 6, "Should be 6"

